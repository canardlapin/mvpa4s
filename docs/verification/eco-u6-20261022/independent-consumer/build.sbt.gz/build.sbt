import org.scalajs.sbtplugin.ScalaJSPlugin.autoImport.*
import sbtcrossproject.CrossPlugin.autoImport.*
import sbtcrossproject.CrossType
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*
ThisBuild / scalaVersion := "3.7.4"
lazy val provider = uri("https://github.com/canardlapin/mvpa4s.git#c27469484bf760c34cd896dabe4fe1c384a83b45")
lazy val common = Seq(scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked"),
  libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test)
lazy val surface = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Pure).in(file("surface"))
  .settings(common).jvmConfigure(_.dependsOn(ProjectRef(provider, "surfaceJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "surfaceJS")))
lazy val atlas = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Pure).in(file("atlas"))
  .settings(common).jvmConfigure(_.dependsOn(ProjectRef(provider, "atlasJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "atlasJS")))
lazy val root = project.in(file(".")).aggregate(surface.jvm, surface.js, atlas.jvm, atlas.js)
  .settings(publish / skip := true)
